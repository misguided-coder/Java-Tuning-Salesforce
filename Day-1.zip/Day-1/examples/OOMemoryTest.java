package com.example;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class OOMemoryTest {
	
	List<String> memoryEater = new ArrayList<>();
		
	public static void main(String[] args) throws InterruptedException  {
		
		for(int i=0;i<999999999;i++) {
			memoryEater.add(new String("Memory is going to finish soon, save it - "+i));			
			//TimeUnit.SECONDS.sleep(10);
		}
		
		System.out.println("Finish Border Line!!!!!");
		
	}

}
