package com.example;

public class ProductNotFoundException extends Exception {
    	
	private static final long serialVersionUID =  292583730112873405L;

	public ProductNotFoundException() {
	}
}
