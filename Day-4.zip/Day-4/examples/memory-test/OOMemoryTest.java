import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class OOMemoryTest {
	
	static List<String> memoryEater = new ArrayList<>();
		
	public static void main(String[] args) throws InterruptedException  {
		
		for(int i=0;i<999999999;i++) {
			memoryEater.add(new String("Memory is going to finish soon, save it - "+i));			
			TimeUnit.MILLISECONDS.sleep(50);
			new Employee("Ram "+i);
			if(i%100 == 0) 
			      System.gc();
			System.out.println("Filling memory soon......");
		}
		
		System.out.println("Finish Border Line!!!!!");
		
	}
	
}


class Employee {
	
	String name;

	public Employee(String name){
		this.name = name;
	}
	
	@Override
	protected void finalize() {
		System.out.println("Employee Object being destroyed by Finalizer Thread and already collected by GC");
		try {
			TimeUnit.MILLISECONDS.sleep(500);
		}catch(Exception e){}
	}

}
