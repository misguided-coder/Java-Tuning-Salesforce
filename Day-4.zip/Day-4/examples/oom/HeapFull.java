import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

//-Xms1g -Xmx1g  -XX:-UseGCOverheadLimit -XX:PretenureSizeThreshold=2k
//GC Overhead Limit exceeded 
//Or Java Heap Space
public class HeapFull {

	static int N = 10000 * 10000;
	static List<String> list = new ArrayList<String>(N);

	public static void main(String args[]) throws Exception {

		for (int idx = 0; idx < N; idx++) {
			list.add(new String("Hip hip hurrey Hip hip hurrey Hip hip hurrey Hip hip hurrey Hip hip hurrey Hip hip hurrey Hip hip hurrey Hip hip hurrey Hip hip hurrey Hip hip hurrey Hip hip hurrey Hip hip hurrey Hip hip hurrey Hip hip hurrey Hip hip hurrey Hip hip hurrey Hip hip hurrey Hip hip hurrey Hip hip hurrey Hip hip hurrey Hip hip hurrey Hip hip hurrey Hip hip hurrey Hip hip hurrey Hip hip hurrey Hip hip hurrey Hip hip hurrey Hip hip hurrey Hip hip hurrey Hip hip hurrey Hip hip hurrey Hip hip hurrey Hip hip hurrey Hip hip hurrey Hip hip hurrey Hip hip hurrey Hip hip hurrey Hip hip hurrey Hip hip hurrey Hip hip hurrey Hip hip hurrey Hip hip hurrey Hip hip hurrey Hip hip hurrey Hip hip hurrey Hip hip hurrey Hip hip hurrey Hip hip hurrey Hip hip hurrey Hip hip hurrey Hip hip hurrey Hip hip hurrey Hip hip hurrey Hip hip hurrey Hip hip hurrey Hip hip hurrey Hip hip hurrey Hip hip hurrey Hip hip hurrey Hip hip hurrey Hip hip hurrey Hip hip hurrey Hip hip hurrey Hip hip hurrey Hip hip hurrey Hip hip hurrey Hip hip hurrey Hip hip hurrey Hip hip hurrey Hip hip hurrey Hip hip hurrey Hip hip hurrey Hip hip hurrey Hip hip hurrey Hip hip hurrey Hip hip hurrey Hip hip hurrey Hip hip hurrey Hip hip hurrey Hip hip hurrey Hip hip hurrey Hip hip hurrey Hip hip hurrey Hip hip hurrey Hip hip hurrey Hip hip hurrey Hip hip hurrey Hip hip hurrey Hip hip hurrey Hip hip hurrey Hip hip hurrey Hip hip hurrey Hip hip hurrey Hip hip hurrey Hip hip hurrey Hip hip hurrey"+idx));
			//TimeUnit.MILLISECONDS.sleep(5);
			System.out.println("Adding object!!");
		}
		
		System.out.println("Done!!");
	}
}
